//
//  ExampleLib.h
//  ExampleLib
//
//  Created by Noah Gilmore on 6/24/20.
//

#import <Foundation/Foundation.h>

//! Project version number for ExampleLib.
FOUNDATION_EXPORT double ExampleLibVersionNumber;

//! Project version string for ExampleLib.
FOUNDATION_EXPORT const unsigned char ExampleLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ExampleLib/PublicHeader.h>


