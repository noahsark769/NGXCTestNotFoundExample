//
//  SceneDelegate.h
//  NGXCTestNotFoundExample
//
//  Created by Noah Gilmore on 6/24/20.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

