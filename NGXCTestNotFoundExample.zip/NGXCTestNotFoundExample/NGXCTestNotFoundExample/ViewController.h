//
//  ViewController.h
//  NGXCTestNotFoundExample
//
//  Created by Noah Gilmore on 6/24/20.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

